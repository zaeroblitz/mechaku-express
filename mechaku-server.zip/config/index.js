const path = require("path");

module.exports = {
  url: "mongodb+srv://zaeroblitz:nvrmore679320@cluster0.y4l1vca.mongodb.net/mechaku?retryWrites=true&w=majority",
  // url: "mongodb://localhost:27017/mechaku",
  rootPath: path.resolve(__dirname, ".."),
};
